/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QSlider *horizontalSlider;
    QSlider *horizontalSlider_2;
    QSlider *horizontalSlider_3;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *pushButton_5;
    QPushButton *red_hist;
    QPushButton *green_hist;
    QPushButton *blue_hist;
    QPushButton *y_hist;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QSlider *brightness;
    QSlider *contrast;
    QLabel *label_6;
    QLabel *label_7;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(900, 600);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 20, 350, 350));
        label->setScaledContents(true);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(510, 20, 350, 350));
        label_2->setScaledContents(true);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(690, 380, 171, 27));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setEnabled(true);
        pushButton_2->setGeometry(QRect(510, 380, 131, 27));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(40, 380, 99, 27));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setEnabled(true);
        pushButton_4->setGeometry(QRect(140, 380, 99, 27));
        horizontalSlider = new QSlider(centralWidget);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(60, 460, 331, 29));
        horizontalSlider->setCursor(QCursor(Qt::ClosedHandCursor));
        horizontalSlider->setMinimum(-250);
        horizontalSlider->setMaximum(250);
        horizontalSlider->setSingleStep(0);
        horizontalSlider->setOrientation(Qt::Horizontal);
        horizontalSlider_2 = new QSlider(centralWidget);
        horizontalSlider_2->setObjectName(QStringLiteral("horizontalSlider_2"));
        horizontalSlider_2->setGeometry(QRect(60, 490, 331, 29));
        horizontalSlider_2->setCursor(QCursor(Qt::ClosedHandCursor));
        horizontalSlider_2->setMinimum(-250);
        horizontalSlider_2->setMaximum(250);
        horizontalSlider_2->setSingleStep(0);
        horizontalSlider_2->setOrientation(Qt::Horizontal);
        horizontalSlider_3 = new QSlider(centralWidget);
        horizontalSlider_3->setObjectName(QStringLiteral("horizontalSlider_3"));
        horizontalSlider_3->setGeometry(QRect(60, 430, 331, 29));
        horizontalSlider_3->setCursor(QCursor(Qt::ClosedHandCursor));
        horizontalSlider_3->setMinimum(-255);
        horizontalSlider_3->setMaximum(255);
        horizontalSlider_3->setSingleStep(0);
        horizontalSlider_3->setValue(0);
        horizontalSlider_3->setOrientation(Qt::Horizontal);
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 430, 16, 17));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 460, 16, 17));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(40, 490, 16, 17));
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(170, 520, 99, 27));
        red_hist = new QPushButton(centralWidget);
        red_hist->setObjectName(QStringLiteral("red_hist"));
        red_hist->setEnabled(true);
        red_hist->setGeometry(QRect(300, 380, 31, 27));
        QFont font;
        font.setPointSize(11);
        font.setBold(false);
        font.setWeight(50);
        red_hist->setFont(font);
        red_hist->setCheckable(true);
        red_hist->setChecked(true);
        green_hist = new QPushButton(centralWidget);
        green_hist->setObjectName(QStringLiteral("green_hist"));
        green_hist->setEnabled(true);
        green_hist->setGeometry(QRect(330, 380, 31, 27));
        QFont font1;
        font1.setBold(false);
        font1.setWeight(50);
        green_hist->setFont(font1);
        green_hist->setCheckable(true);
        green_hist->setChecked(true);
        blue_hist = new QPushButton(centralWidget);
        blue_hist->setObjectName(QStringLiteral("blue_hist"));
        blue_hist->setEnabled(true);
        blue_hist->setGeometry(QRect(360, 380, 31, 27));
        blue_hist->setFont(font1);
        blue_hist->setCheckable(true);
        blue_hist->setChecked(true);
        y_hist = new QPushButton(centralWidget);
        y_hist->setObjectName(QStringLiteral("y_hist"));
        y_hist->setEnabled(true);
        y_hist->setGeometry(QRect(270, 380, 31, 27));
        y_hist->setCheckable(true);
        y_hist->setChecked(true);
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setEnabled(true);
        pushButton_6->setGeometry(QRect(510, 420, 181, 27));
        pushButton_7 = new QPushButton(centralWidget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setEnabled(true);
        pushButton_7->setGeometry(QRect(510, 450, 351, 27));
        brightness = new QSlider(centralWidget);
        brightness->setObjectName(QStringLiteral("brightness"));
        brightness->setGeometry(QRect(610, 520, 241, 29));
        brightness->setCursor(QCursor(Qt::ClosedHandCursor));
        brightness->setMinimum(0);
        brightness->setMaximum(100);
        brightness->setSingleStep(0);
        brightness->setValue(50);
        brightness->setOrientation(Qt::Horizontal);
        contrast = new QSlider(centralWidget);
        contrast->setObjectName(QStringLiteral("contrast"));
        contrast->setGeometry(QRect(610, 490, 241, 29));
        contrast->setCursor(QCursor(Qt::ClosedHandCursor));
        contrast->setMinimum(0);
        contrast->setMaximum(100);
        contrast->setSingleStep(0);
        contrast->setPageStep(10);
        contrast->setValue(50);
        contrast->setOrientation(Qt::Horizontal);
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(530, 490, 67, 17));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(520, 520, 81, 20));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 900, 25));
        MainWindow->setMenuBar(menuBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "RGB Histograms", 0));
        label->setText(QString());
        label_2->setText(QString());
        pushButton->setText(QApplication::translate("MainWindow", "Save Image Histogram", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Load Histogram", 0));
        pushButton_3->setText(QApplication::translate("MainWindow", "Save", 0));
        pushButton_4->setText(QApplication::translate("MainWindow", "Load", 0));
#ifndef QT_NO_TOOLTIP
        horizontalSlider_3->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#ff0000;\">R</span></p></body></html>", 0));
        label_4->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#4cbe00;\">G</span></p></body></html>", 0));
        label_5->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#002eff;\">B</span></p></body></html>", 0));
        pushButton_5->setText(QApplication::translate("MainWindow", "Reset", 0));
        red_hist->setText(QApplication::translate("MainWindow", "R", 0));
        green_hist->setText(QApplication::translate("MainWindow", "G", 0));
        blue_hist->setText(QApplication::translate("MainWindow", "B", 0));
        y_hist->setText(QApplication::translate("MainWindow", "Y", 0));
        pushButton_6->setText(QApplication::translate("MainWindow", "Histogram Equalization", 0));
        pushButton_7->setText(QApplication::translate("MainWindow", "Contrast Limited Adaptive Histogram Equalization", 0));
#ifndef QT_NO_TOOLTIP
        brightness->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        contrast->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_6->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-style:italic;\">Contrast</span></p></body></html>", 0));
        label_7->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-style:italic;\">Brightness</span></p></body></html>", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
