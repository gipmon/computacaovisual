/********************************************************************************
** Form generated from reading UI file 'histogram.ui'
**
** Created by: Qt User Interface Compiler version 5.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HISTOGRAM_H
#define UI_HISTOGRAM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_histogram
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label_2;

    void setupUi(QDialog *histogram)
    {
        if (histogram->objectName().isEmpty())
            histogram->setObjectName(QStringLiteral("histogram"));
        histogram->resize(474, 383);
        buttonBox = new QDialogButtonBox(histogram);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(390, 10, 81, 241));
        buttonBox->setOrientation(Qt::Vertical);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label_2 = new QLabel(histogram);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 10, 350, 350));
        label_2->setScaledContents(true);

        retranslateUi(histogram);
        QObject::connect(buttonBox, SIGNAL(accepted()), histogram, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), histogram, SLOT(reject()));

        QMetaObject::connectSlotsByName(histogram);
    } // setupUi

    void retranslateUi(QDialog *histogram)
    {
        histogram->setWindowTitle(QApplication::translate("histogram", "Dialog", 0));
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class histogram: public Ui_histogram {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HISTOGRAM_H
